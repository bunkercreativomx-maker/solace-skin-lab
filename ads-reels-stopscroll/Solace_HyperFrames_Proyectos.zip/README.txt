Descomprime el ZIP. Abre cada carpeta de anuncio como proyecto en la app de HyperFrames. Los videos finales se descargan en el otro ZIP.
