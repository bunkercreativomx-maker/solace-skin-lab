Descomprime el ZIP y abre la carpeta del reel en HyperFrames.
